import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Box, Typography, Button, Card, CardContent, Chip, IconButton, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, Alert, CircularProgress, List, ListItem, ListItemText, ListItemSecondaryAction,
  Divider, Grid, FormControlLabel, Switch
} from '@mui/material';
import {
  PlayArrow, Stop, Pause, Add, Edit, Delete, Timer, AttachMoney, AccessTime
} from '@mui/icons-material';
import { useAuth } from '../AuthContext';
import { useToast } from '../contexts/ToastContext';
import useApi from '../hooks/useApi';
import { formatTimeTrackerTimestamp, formatTimeTrackerEndTime, getCurrentUTCTimestamp, localToUTC } from '../utils/timezone';
import dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';

dayjs.extend(duration);

const TimeTracker = React.memo(function TimeTracker({ ticketId, onTimeUpdate, isDeleting = false }) {
  const { user } = useAuth();
  const api = useApi();
  const { success } = useToast();
  const [isRunning, setIsRunning] = useState(false);
  const [currentSession, setCurrentSession] = useState(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [timeEntries, setTimeEntries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState(null);
  const [formData, setFormData] = useState({
    start_time: '',
    end_time: '',
    duration_minutes: '',
    description: '',
    is_billable: true
  });
  
  // Prevent multiple simultaneous API calls
  const fetchingRef = useRef(false);
  const isMountedRef = useRef(true);

  const fetchTimeEntries = useCallback(async () => {
    // Prevent multiple simultaneous calls
    if (fetchingRef.current) return;
    
    // Don't fetch if component is unmounted
    if (!isMountedRef.current) {
      console.log('Component unmounted, skipping time entry fetch');
      return;
    }
    
    // Don't fetch if ticket is being deleted
    if (isDeleting) {
      console.log('Ticket is being deleted, skipping time entry fetch');
      return;
    }
    
    // No localStorage checks - just fetch directly from server
    
    try {
      fetchingRef.current = true;
      setLoading(true);
      setError(null);
      const response = await api.get(`/tickets/${ticketId}/time-entries/`);
      setTimeEntries(response || []);
    } catch (err) {
      console.error('Error fetching time entries:', err);
      // Handle different error types gracefully
      if (err.response?.status === 404) {
        // Ticket not found or no time entries - this is normal
        setTimeEntries([]);
      } else if (err.response?.status === 401) {
        // Authentication error - user might need to log in
        console.log('Authentication required for time entries');
        setTimeEntries([]);
      } else {
        // Other errors
        setError('Failed to load time entries');
        setTimeEntries([]);
      }
    } finally {
      setLoading(false);
      fetchingRef.current = false;
    }
  }, [api, ticketId, isDeleting]);

  const startTimer = useCallback((startTime) => {
    setCurrentSession({ startTime });
    setIsRunning(true);
    // Do not persist in browser storage; server is source of truth
  }, [ticketId]);

  useEffect(() => {
    // Only fetch if we have a valid ticketId and not deleting
    if (ticketId && !isDeleting) {
      fetchTimeEntries();
    }
  }, [ticketId, isDeleting]); // Removed fetchTimeEntries from dependencies to prevent infinite loops

  // Start timer only once when component mounts
  useEffect(() => {
    // Do not read browser storage; rely on server time entries instead
  }, [ticketId]);

  useEffect(() => {
    let interval;
    if (isRunning && currentSession) {
      interval = setInterval(() => {
        setElapsedTime(Date.now() - currentSession.startTime);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, currentSession]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const stopTimer = async () => {
    if (!currentSession) return;

    const endTime = Date.now();
    const durationMinutes = Math.round((endTime - currentSession.startTime) / 60000);

    setFormData({
      start_time: localToUTC(currentSession.startTime),
      end_time: localToUTC(endTime),
      duration_minutes: durationMinutes.toString(),
      description: '',
      is_billable: true
    });

    setDialogOpen(true);
    setIsRunning(false);
    setCurrentSession(null);
    setElapsedTime(0);
    // No browser storage cleanup needed
  };

  const pauseTimer = () => {
    setIsRunning(false);
  };

  const resumeTimer = () => {
    setIsRunning(true);
  };

  const handleSaveTimeEntry = useCallback(async () => {
    try {
      // Validate required fields
      if (!formData.start_time) {
        setError('Start time is required');
        return;
      }

      const entryData = {
        start_time: formData.start_time,
        end_time: formData.end_time || null,
        duration_minutes: parseInt(formData.duration_minutes) || null,
        description: formData.description || '',
        is_billable: formData.is_billable
      };

      console.log('Sending time entry data:', entryData);

      if (editingEntry) {
        await api.put(`/tickets/${ticketId}/time-entries/${editingEntry.entry_id}`, entryData);
      } else {
        await api.post(`/tickets/${ticketId}/time-entries/`, entryData);
      }

      setDialogOpen(false);
      setEditingEntry(null);
      setFormData({
        start_time: '',
        end_time: '',
        duration_minutes: '',
        description: '',
        is_billable: true
      });
      
      fetchTimeEntries();
      // Only call onTimeUpdate if it's a function and not causing re-renders
      if (onTimeUpdate && typeof onTimeUpdate === 'function') {
        setTimeout(() => onTimeUpdate(), 100); // Small delay to prevent immediate re-render
      }
    } catch (err) {
      console.error('Error saving time entry:', err);
      
      // Handle validation errors specifically
      if (err.response?.status === 422) {
        const validationErrors = err.response?.data?.detail;
        if (Array.isArray(validationErrors)) {
          const errorMessages = validationErrors.map(error => `${error.loc.join('.')}: ${error.msg}`).join(', ');
          setError(`Validation error: ${errorMessages}`);
        } else {
          setError('Invalid data format. Please check your input.');
        }
      } else {
        setError('Failed to save time entry');
      }
    }
  }, [formData, editingEntry, ticketId, api, fetchTimeEntries, onTimeUpdate]);

  const handleEditEntry = (entry) => {
    setEditingEntry(entry);
    setFormData({
      start_time: localToUTC(entry.start_time),
      end_time: entry.end_time ? localToUTC(entry.end_time) : '',
      duration_minutes: entry.duration_minutes?.toString() || '',
      description: entry.description || '',
      is_billable: entry.is_billable
    });
    setDialogOpen(true);
  };

  const handleDeleteEntry = async (entryId) => {
    if (!window.confirm('Are you sure you want to delete this time entry?')) return;

    try {
      await api.delete(`/tickets/${ticketId}/time-entries/${entryId}`);
      fetchTimeEntries();
      if (onTimeUpdate) onTimeUpdate();
    } catch (err) {
      console.error('Error deleting time entry:', err);
      setError('Failed to delete time entry');
    }
  };

  const formatDuration = (milliseconds) => {
    const duration = dayjs.duration(milliseconds);
    const hours = Math.floor(duration.asHours());
    const minutes = duration.minutes();
    const seconds = duration.seconds();
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const getTotalBillableTime = () => {
    return timeEntries
      .filter(entry => entry.is_billable && entry.duration_minutes)
      .reduce((total, entry) => total + entry.duration_minutes, 0);
  };

  const getTotalNonBillableTime = () => {
    return timeEntries
      .filter(entry => !entry.is_billable && entry.duration_minutes)
      .reduce((total, entry) => total + entry.duration_minutes, 0);
  };

  return (
    <Box>
      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Timer Controls */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
            <Timer color="primary" />
            Time Tracker
          </Typography>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
            <Typography variant="h4" fontFamily="monospace">
              {formatDuration(elapsedTime)}
            </Typography>
            
            <Box sx={{ display: 'flex', gap: 1 }}>
              {!isRunning && !currentSession && (
                <Button
                  variant="contained"
                  color="success"
                  startIcon={<PlayArrow />}
                  onClick={() => startTimer(Date.now())}
                >
                  Start
                </Button>
              )}
              
              {isRunning && (
                <>
                  <Button
                    variant="outlined"
                    color="warning"
                    startIcon={<Pause />}
                    onClick={pauseTimer}
                  >
                    Pause
                  </Button>
                  <Button
                    variant="contained"
                    color="error"
                    startIcon={<Stop />}
                    onClick={stopTimer}
                  >
                    Stop
                  </Button>
                </>
              )}
              
              {!isRunning && currentSession && (
                <Button
                  variant="contained"
                  color="info"
                  startIcon={<PlayArrow />}
                  onClick={resumeTimer}
                >
                  Resume
                </Button>
              )}
            </Box>
          </Box>

          {/* Time Summary */}
          <Grid container spacing={2}>
            <Grid item xs={4}>
              <Box textAlign="center">
                <Typography variant="h6" color="success.main">
                  {Math.round(getTotalBillableTime() / 60 * 10) / 10}h
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Billable
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={4}>
              <Box textAlign="center">
                <Typography variant="h6" color="warning.main">
                  {Math.round(getTotalNonBillableTime() / 60 * 10) / 10}h
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Non-Billable
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={4}>
              <Box textAlign="center">
                <Typography variant="h6" color="primary.main">
                  {Math.round((getTotalBillableTime() + getTotalNonBillableTime()) / 60 * 10) / 10}h
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Total
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Time Entries List */}
      <Card>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">
              Time Entries
            </Typography>
            <Button
              variant="outlined"
              startIcon={<Add />}
              onClick={() => {
                setEditingEntry(null);
                setFormData({
                  start_time: '',
                  end_time: '',
                  duration_minutes: '',
                  description: '',
                  is_billable: true
                });
                setDialogOpen(true);
              }}
            >
              Add Entry
            </Button>
          </Box>

          {loading ? (
            <Box display="flex" justifyContent="center" p={3}>
              <CircularProgress />
            </Box>
          ) : timeEntries.length === 0 ? (
            <Typography color="text.secondary" textAlign="center" py={3}>
              No time entries yet
            </Typography>
          ) : (
            <List>
              {timeEntries.map((entry, index) => (
                <React.Fragment key={entry.entry_id}>
                  <ListItem>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Typography variant="body1">
                            {formatTimeTrackerTimestamp(entry.start_time)}
                            {entry.end_time && ` - ${formatTimeTrackerEndTime(entry.end_time)}`}
                          </Typography>
                          <Chip
                            label={`${Math.round(entry.duration_minutes / 60 * 10) / 10}h`}
                            size="small"
                            color="primary"
                          />
                          {entry.is_billable && (
                            <Chip
                              icon={<AttachMoney />}
                              label="Billable"
                              size="small"
                              color="success"
                            />
                          )}
                        </Box>
                      }
                      secondary={
                        <Typography variant="body2" color="text.secondary">
                          {entry.description || 'No description'}
                        </Typography>
                      }
                    />
                    <ListItemSecondaryAction>
                      <IconButton
                        edge="end"
                        onClick={() => handleEditEntry(entry)}
                        size="small"
                      >
                        <Edit />
                      </IconButton>
                      <IconButton
                        edge="end"
                        onClick={() => handleDeleteEntry(entry.entry_id)}
                        size="small"
                        color="error"
                      >
                        <Delete />
                      </IconButton>
                    </ListItemSecondaryAction>
                  </ListItem>
                  {index < timeEntries.length - 1 && <Divider />}
                </React.Fragment>
              ))}
            </List>
          )}
        </CardContent>
      </Card>

      {/* Time Entry Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingEntry ? 'Edit Time Entry' : 'Add Time Entry'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Start Time"
                type="datetime-local"
                value={formData.start_time}
                onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="End Time"
                type="datetime-local"
                value={formData.end_time}
                onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Duration (minutes)"
                type="number"
                value={formData.duration_minutes}
                onChange={(e) => setFormData({ ...formData, duration_minutes: e.target.value })}
                InputProps={{
                  startAdornment: <AccessTime sx={{ mr: 1, color: 'action.active' }} />
                }}
              />
            </Grid>
            <Grid item xs={6}>
              <Box sx={{ display: 'flex', alignItems: 'center', height: '100%' }}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={formData.is_billable}
                      onChange={(e) => setFormData({ ...formData, is_billable: e.target.checked })}
                    />
                  }
                  label="Billable"
                />
              </Box>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="What work was performed during this time?"
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveTimeEntry} variant="contained">
            {editingEntry ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
});

export default TimeTracker; 